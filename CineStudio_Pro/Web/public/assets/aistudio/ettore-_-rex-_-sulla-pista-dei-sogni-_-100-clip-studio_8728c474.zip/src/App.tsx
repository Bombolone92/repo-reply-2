import React, { useState, useMemo, useEffect } from 'react';
import {
  CHARACTERS,
  ENVIRONMENTS,
  EPISODES_DATA,
  SceneClip,
  generatePromptForScene
} from './data/seriesData';
import { getSceneVisualConfig } from './data/sceneAssets';
import { VideoCanvasPlayer } from './components/VideoCanvasPlayer';
import {
  Play,
  Film,
  Sparkles,
  BookOpen,
  Users,
  MapPin,
  Download,
  Search,
  CheckCircle2,
  Clock,
  ChevronLeft,
  ChevronRight,
  Copy,
  Check,
  Tv,
  ListVideo
} from 'lucide-react';

export default function App() {
  const [currentGlobalIndex, setCurrentGlobalIndex] = useState<number>(0); // 0 = Clip 1, 1 = Clip 2...
  const [selectedEpisode, setSelectedEpisode] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'canvas_player' | 'video_explorer' | 'prompts' | 'characters' | 'locations'>('canvas_player');
  const [copied, setCopied] = useState<boolean>(false);
  const [autoPlayNext, setAutoPlayNext] = useState<boolean>(true);
  const [clipStatus, setClipStatus] = useState<Record<number, 'pending' | 'in_progress' | 'done'>>(() => {
    try {
      const saved = localStorage.getItem('ettore_rex_status');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const allClips = useMemo(() => {
    return EPISODES_DATA.flatMap((ep) => ep.scenes);
  }, []);

  const currentClip: SceneClip = allClips[currentGlobalIndex] || allClips[0];

  const currentPrompt = useMemo(() => {
    return generatePromptForScene(currentClip);
  }, [currentClip]);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateStatus = (globalNum: number, status: 'pending' | 'in_progress' | 'done') => {
    const updated = { ...clipStatus, [globalNum]: status };
    setClipStatus(updated);
    try {
      localStorage.setItem('ettore_rex_status', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleNext = () => {
    if (currentGlobalIndex < allClips.length - 1) {
      setCurrentGlobalIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentGlobalIndex > 0) {
      setCurrentGlobalIndex((prev) => prev - 1);
    }
  };

  const playClip = (globalNum: number) => {
    setCurrentGlobalIndex(globalNum - 1);
    setActiveTab('canvas_player');
  };

  const filteredClips = useMemo(() => {
    return allClips.filter((c) => {
      const matchesEp = selectedEpisode === 0 || c.episodeNumber === selectedEpisode;
      const matchesSearch =
        searchQuery === '' ||
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.brief.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.activeCharacters.some((ch) => ch.toLowerCase().includes(searchQuery.toLowerCase())) ||
        c.environmentName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesEp && matchesSearch;
    });
  }, [allClips, selectedEpisode, searchQuery]);

  const completedCount = useMemo(() => {
    return Object.values(clipStatus).filter((s) => s === 'done').length;
  }, [clipStatus]);

  const exportAllPromptsTxt = () => {
    const text = allClips
      .map(
        (c) =>
          `------------------------------------------------------------\n` +
          `CLIP ${c.globalNumber}/100 — EPISODIO ${c.episodeNumber}, SCENA ${c.sceneNumber}: ${c.title}\n` +
          `------------------------------------------------------------\n\n` +
          generatePromptForScene(c) +
          `\n\nAUDIO SUGGERITO: ${c.audioNotes}\n\n`
      )
      .join('\n');

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Ettore_e_Rex_100_Prompt_Video_Pixar.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-stone-900 text-stone-100 flex flex-col font-sans selection:bg-amber-500 selection:text-stone-900">
      {/* Top Main Navigation Header */}
      <header className="border-b border-stone-800 bg-stone-950/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-red-600 flex items-center justify-center shadow-lg shadow-amber-900/40 text-2xl font-bold">
              🐾
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black tracking-wider uppercase bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded border border-amber-500/30">
                  Scuderia DOG · Serie Pixar 3D
                </span>
                <span className="text-xs text-stone-400">9:16 Vertical · 100 Clip</span>
              </div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Ettore & Rex <span className="text-amber-400 font-normal text-sm sm:text-base">— Sulla Pista dei Sogni</span>
              </h1>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-stone-900 p-1 rounded-xl border border-stone-800 text-xs sm:text-sm">
            <button
              onClick={() => setActiveTab('canvas_player')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'canvas_player'
                  ? 'bg-amber-600 text-white font-bold shadow-sm'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
              }`}
            >
              <Tv className="w-4 h-4 text-amber-300" />
              <span>Video Canvas</span>
            </button>

            <button
              onClick={() => setActiveTab('video_explorer')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'video_explorer'
                  ? 'bg-amber-600 text-white font-bold shadow-sm'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
              }`}
            >
              <ListVideo className="w-4 h-4" />
              <span>Explorer Serie ({completedCount}/100)</span>
            </button>

            <button
              onClick={() => setActiveTab('prompts')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'prompts'
                  ? 'bg-amber-600 text-white font-bold shadow-sm'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Prompt AI</span>
            </button>

            <button
              onClick={() => setActiveTab('characters')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'characters'
                  ? 'bg-amber-600 text-white font-bold shadow-sm'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Cast</span>
            </button>

            <button
              onClick={() => setActiveTab('locations')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                activeTab === 'locations'
                  ? 'bg-amber-600 text-white font-bold shadow-sm'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>Set</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main App Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* TAB 1: CANVAS VIDEO PLAYER */}
        {activeTab === 'canvas_player' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Center-Left: The Interactive 9:16 Canvas Animator (5 cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <VideoCanvasPlayer
                clip={currentClip}
                onNextClip={handleNext}
                onPrevClip={handlePrev}
                autoPlayNext={autoPlayNext}
                onToggleAutoPlayNext={() => setAutoPlayNext(!autoPlayNext)}
                onMarkDone={() =>
                  updateStatus(
                    currentClip.globalNumber,
                    clipStatus[currentClip.globalNumber] === 'done' ? 'pending' : 'done'
                  )
                }
                isDone={clipStatus[currentClip.globalNumber] === 'done'}
              />
            </div>

            {/* Right Column: Episode Guide, Current Scene Details & Scene Playlist (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              {/* Top Banner: Episode details */}
              <div className="bg-stone-950/80 border border-stone-800 rounded-3xl p-5 space-y-3 shadow-xl">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-amber-400 px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/20">
                    Episodio {currentClip.episodeNumber}: {EPISODES_DATA[currentClip.episodeNumber - 1]?.title}
                  </span>
                  <span className="text-xs text-stone-400 font-mono">
                    Scena {currentClip.sceneNumber} di 20 (Clip Globale #{currentClip.globalNumber})
                  </span>
                </div>

                <h2 className="text-2xl font-bold text-white tracking-tight">
                  {currentClip.title}
                </h2>

                <p className="text-sm text-stone-300 leading-relaxed">
                  {currentClip.sceneDescription}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-stone-800 text-xs">
                  <div className="space-y-1">
                    <span className="text-stone-400 font-semibold">Azione Personaggi:</span>
                    <p className="text-stone-200">{currentClip.actionDescription}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-stone-400 font-semibold">Regia & Movimento Camera:</span>
                    <p className="text-stone-200">{currentClip.cameraDirection}</p>
                  </div>
                </div>

                <div className="pt-2 text-xs text-amber-300/90 flex items-center gap-2">
                  <span>🎵</span>
                  <span><strong>Audio & Doppiaggio:</strong> {currentClip.audioNotes}</span>
                </div>
              </div>

              {/* Scene Stepper in Current Episode */}
              <div className="bg-stone-950 border border-stone-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-400 flex items-center gap-2">
                    <Film className="w-4 h-4 text-amber-400" /> Scaletta Scene Episodio {currentClip.episodeNumber}
                  </span>
                  <span className="text-xs text-amber-400 font-mono">
                    20 Clip verticali (15s ciascuna)
                  </span>
                </div>

                <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                  {EPISODES_DATA[currentClip.episodeNumber - 1]?.scenes.map((s) => {
                    const isSelected = s.globalNumber === currentClip.globalNumber;
                    const status = clipStatus[s.globalNumber] || 'pending';
                    return (
                      <button
                        key={s.globalNumber}
                        onClick={() => playClip(s.globalNumber)}
                        className={`h-11 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center border ${
                          isSelected
                            ? 'bg-amber-600 text-white border-amber-400 shadow-md scale-105'
                            : status === 'done'
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/80 hover:bg-emerald-900/60'
                            : 'bg-stone-900 text-stone-400 border-stone-800 hover:bg-stone-800 hover:text-stone-200'
                        }`}
                        title={s.title}
                      >
                        <span>{s.sceneNumber}</span>
                        {status === 'done' && <span className="text-[9px] leading-none">✓</span>}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Episode Switcher */}
              <div className="bg-stone-950/60 border border-stone-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wide">
                  Cambia Episodio:
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {EPISODES_DATA.map((ep) => (
                    <button
                      key={ep.number}
                      onClick={() => playClip(ep.scenes[0].globalNumber)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        currentClip.episodeNumber === ep.number
                          ? 'bg-amber-600 text-white shadow-md'
                          : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
                      }`}
                    >
                      Ep. {ep.number}: {ep.title}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: VIDEO EXPLORER & STORYBOARD */}
        {activeTab === 'video_explorer' && (
          <div className="space-y-6">
            <div className="bg-stone-950 border border-stone-800 rounded-3xl p-5 sm:p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                    <ListVideo className="w-6 h-6 text-amber-400" />
                    Explorer Video della Serie — 100 Clip Pixar 3D
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-400 mt-1">
                    Esplora tutte le scene della serie. Clicca su "Guarda in Canvas" su qualunque card per avviare l'animazione e la riproduzione video 9:16.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setAutoPlayNext(true);
                      playClip(1);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white text-xs font-bold rounded-xl shadow-lg transition"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    Guarda Serie dall'Inizio (Autoplay)
                  </button>

                  <button
                    onClick={exportAllPromptsTxt}
                    className="flex items-center gap-2 px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition"
                  >
                    <Download className="w-4 h-4 text-amber-400" />
                    Scarica Testi (.txt)
                  </button>
                </div>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-stone-800">
                <div className="relative flex-1 min-w-[240px]">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cerca scena, personaggio, azione..."
                    className="w-full bg-stone-900 border border-stone-800 rounded-xl pl-9 pr-3 py-2 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-center gap-1 bg-stone-900 p-1 rounded-xl border border-stone-800 text-xs">
                  <button
                    onClick={() => setSelectedEpisode(0)}
                    className={`px-3 py-1.5 rounded-lg transition ${
                      selectedEpisode === 0
                        ? 'bg-amber-600 text-white font-bold'
                        : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    Tutti (100)
                  </button>
                  {[1, 2, 3, 4, 5].map((epNum) => (
                    <button
                      key={epNum}
                      onClick={() => setSelectedEpisode(epNum)}
                      className={`px-3 py-1.5 rounded-lg transition ${
                        selectedEpisode === epNum
                          ? 'bg-amber-600 text-white font-bold'
                          : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      Ep. {epNum}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Grid of 100 Video Scene Cards with Visual Thumbnails */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredClips.map((clip) => {
                const config = getSceneVisualConfig(
                  clip.episodeNumber,
                  clip.sceneNumber,
                  clip.environmentId
                );
                const status = clipStatus[clip.globalNumber] || 'pending';

                return (
                  <div
                    key={clip.globalNumber}
                    className="bg-stone-950 border border-stone-800 hover:border-amber-500/60 rounded-2xl overflow-hidden shadow-lg transition flex flex-col justify-between group"
                  >
                    {/* Visual 9:16 cropped banner preview with Play button */}
                    <div className="relative aspect-[16/10] overflow-hidden bg-stone-900">
                      <img
                        src={config.imageUrl}
                        alt={clip.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                      {/* Badges on top */}
                      <div className="absolute top-2 left-2 flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold bg-black/70 backdrop-blur px-2 py-0.5 rounded text-amber-400">
                          CLIP #{clip.globalNumber}
                        </span>
                        <span className="text-[10px] bg-red-600/90 text-white font-bold px-1.5 py-0.5 rounded">
                          15s
                        </span>
                      </div>

                      {status === 'done' && (
                        <div className="absolute top-2 right-2 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow">
                          <CheckCircle2 className="w-3 h-3" /> Visto
                        </div>
                      )}

                      {/* Play overlay button */}
                      <button
                        onClick={() => playClip(clip.globalNumber)}
                        className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-amber-500/90 hover:bg-amber-400 text-stone-950 flex items-center justify-center shadow-lg transition transform group-hover:scale-110"
                        title="Guarda nel Video Canvas"
                      >
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </button>

                      {/* Scene Title over preview */}
                      <div className="absolute bottom-2 left-2 right-2">
                        <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wide block">
                          Ep. {clip.episodeNumber} · Scena {clip.sceneNumber}
                        </span>
                        <h3 className="text-xs font-bold text-white truncate drop-shadow">
                          {clip.title}
                        </h3>
                      </div>
                    </div>

                    {/* Card Content & Brief */}
                    <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                      <p className="text-xs text-stone-400 line-clamp-2 leading-relaxed">
                        {clip.brief}
                      </p>

                      <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between">
                        <span className="text-[11px] text-stone-500 truncate max-w-[140px]">
                          📍 {clip.environmentName.split('—')[0]}
                        </span>

                        <button
                          onClick={() => playClip(clip.globalNumber)}
                          className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition"
                        >
                          Guarda in Canvas <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: PROMPTS TEXT GENERATOR */}
        {activeTab === 'prompts' && (
          <div className="space-y-6">
            <div className="bg-stone-950 border border-stone-800 rounded-3xl p-5 sm:p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-amber-400" />
                    Archivio & Generatore Prompt Ufficiali 9:16
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-400 mt-1">
                    Ogni prompt rispetta il formato universale Pixar 3D (9:16, 15 sec) pronto da incollare su Runway Gen-3, OpenAI Sora, Luma Dream Machine o Kling AI.
                  </p>
                </div>

                <button
                  onClick={handleCopy}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
                    copied
                      ? 'bg-emerald-600 text-white shadow-lg'
                      : 'bg-amber-600 hover:bg-amber-500 text-white'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4" /> Prompt Copiato!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" /> Copia Prompt Attuale
                    </>
                  )}
                </button>
              </div>

              {/* Current Clip Quick Navigation */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-stone-800 text-xs">
                <span className="text-stone-300">
                  Visualizzando: <strong>Clip #{currentClip.globalNumber}</strong> — Ep. {currentClip.episodeNumber}, Scena {currentClip.sceneNumber}: <em>{currentClip.title}</em>
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    disabled={currentGlobalIndex === 0}
                    className="px-3 py-1 rounded-lg bg-stone-900 border border-stone-700 disabled:opacity-40 text-stone-300"
                  >
                    ← Precedente
                  </button>
                  <button
                    onClick={handleNext}
                    disabled={currentGlobalIndex === allClips.length - 1}
                    className="px-3 py-1 rounded-lg bg-stone-900 border border-stone-700 disabled:opacity-40 text-stone-300"
                  >
                    Successiva →
                  </button>
                </div>
              </div>
            </div>

            {/* Prompt Preview Code Box */}
            <div className="bg-stone-950 border border-stone-800 rounded-3xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between text-xs text-stone-400 pb-2 border-b border-stone-800">
                <span className="font-mono">=== CLIP {currentClip.sceneNumber} — EPISODIO {currentClip.episodeNumber} ===</span>
                <span>Specifiche: 9:16 verticale · 15 secondi · Pixar 3D</span>
              </div>

              <div className="font-mono text-xs sm:text-sm text-stone-300 bg-black/60 p-5 rounded-2xl leading-relaxed whitespace-pre-wrap select-all border border-stone-800/80">
                {currentPrompt}
              </div>

              <div className="pt-2 text-xs text-stone-400">
                💡 <strong>Suggerimento:</strong> Questo prompt è sincronizzato con la scena attualmente selezionata nel Canvas Player.
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CHARACTERS */}
        {activeTab === 'characters' && (
          <div className="space-y-6">
            <div className="bg-stone-950 border border-stone-800 rounded-3xl p-5 sm:p-6">
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                <Users className="w-6 h-6 text-amber-400" /> Schede Personaggi Ufficiali — Stile Pixar 3D
              </h2>
              <p className="text-xs sm:text-sm text-stone-400 mt-1">
                Descrizioni fisiche e caratteriali fisse usate in modo coerente in tutti i 100 video per evitare allucinazioni visive.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {CHARACTERS.map((char) => (
                <div
                  key={char.name}
                  className="bg-stone-950 border border-stone-800 rounded-3xl p-5 flex flex-col justify-between space-y-4 hover:border-stone-700 transition"
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-2xl flex items-center justify-center text-white text-xl font-bold shadow-md"
                        style={{ backgroundColor: char.avatarColor }}
                      >
                        {char.name[0]}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-white leading-tight">{char.name}</h3>
                        <p className="text-xs text-amber-400 font-semibold">{char.breed}</p>
                        <p className="text-[11px] text-stone-500">{char.role}</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs text-stone-300 leading-relaxed border-t border-stone-800 pt-3">
                      <p>
                        <strong className="text-stone-400">Aspetto:</strong> {char.appearance}
                      </p>
                      <p>
                        <strong className="text-stone-400">Collare/Tuta:</strong> {char.collar}
                      </p>
                      <p>
                        <strong className="text-stone-400">Occhi:</strong> {char.eyes}
                      </p>
                      <p>
                        <strong className="text-stone-400">Personalità:</strong> {char.personality}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-stone-800/80 text-[11px] text-stone-500 italic">
                    "{char.description}"
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: LOCATIONS */}
        {activeTab === 'locations' && (
          <div className="space-y-6">
            <div className="bg-stone-950 border border-stone-800 rounded-3xl p-5 sm:p-6">
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                <MapPin className="w-6 h-6 text-amber-400" /> Ambientazioni Principali della Serie
              </h2>
              <p className="text-xs sm:text-sm text-stone-400 mt-1">
                Palette cromatica, illuminazione dorata e dettagli architetturali per i tre set della storia.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {Object.values(ENVIRONMENTS).map((env) => (
                <div
                  key={env.id}
                  className="bg-stone-950 border border-stone-800 rounded-3xl p-5 flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: env.color }}
                      />
                      <h3 className="font-bold text-lg text-white">{env.name}</h3>
                    </div>
                    <p className="text-xs text-amber-400 font-semibold">{env.tagline}</p>
                    <p className="text-xs text-stone-300 leading-relaxed">{env.description}</p>

                    <div className="space-y-2 text-xs border-t border-stone-800 pt-3">
                      <p>
                        <strong className="text-stone-400">Luce:</strong> {env.lighting}
                      </p>
                      <p>
                        <strong className="text-stone-400">Dettagli iconici:</strong> {env.details}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
                    <span>
                      Scene ambientate: <strong>{allClips.filter((c) => c.environmentId === env.id).length}</strong> / 100
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-800 bg-stone-950 py-4 px-6 text-center text-xs text-stone-500">
        Ettore & Rex – Sulla Pista dei Sogni · Serie animata 3D per bambini (4-9 anni) · Player Canvas 9:16 & Video Explorer
      </footer>
    </div>
  );
}

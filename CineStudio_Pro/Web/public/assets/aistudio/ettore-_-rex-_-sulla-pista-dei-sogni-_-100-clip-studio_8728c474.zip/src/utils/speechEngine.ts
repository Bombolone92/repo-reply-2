// Italian Speech Synthesis Engine for Ettore & Rex dialogue tracks

export class SpeechEngine {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  public isVoiceEnabled: boolean = true;
  private currentSpeaker: string | null = null;
  private onSpeakingChange: ((isSpeaking: boolean, speaker: string | null) => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    this.voices = this.synth.getVoices().filter((v) => v.lang.startsWith('it') || v.lang.startsWith('en'));
  }

  public setSpeakingListener(listener: (isSpeaking: boolean, speaker: string | null) => void) {
    this.onSpeakingChange = listener;
  }

  public speakDialogue(text: string, speaker: string) {
    if (!this.isVoiceEnabled || !this.synth) return;

    // Stop current speech
    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'it-IT';

    // Pick best Italian voice if available
    const itVoice = this.voices.find((v) => v.lang.includes('it'));
    if (itVoice) {
      utterance.voice = itVoice;
    }

    // Adjust pitch and rate to match characters
    const upperSpeaker = speaker.toUpperCase();
    if (upperSpeaker.includes('ETTORE')) {
      utterance.pitch = 1.35; // Young, joyful bulldog
      utterance.rate = 1.05;
    } else if (upperSpeaker.includes('REX')) {
      utterance.pitch = 0.82; // Deep, calm German shepherd
      utterance.rate = 0.95;
    } else if (upperSpeaker.includes('BAFFI')) {
      utterance.pitch = 1.15; // Polite french poodle
      utterance.rate = 1.0;
    } else if (upperSpeaker.includes('BRUNO')) {
      utterance.pitch = 0.68; // Gruff, arrogant great dane
      utterance.rate = 0.88;
    } else if (upperSpeaker.includes('ZAMPA')) {
      utterance.pitch = 0.88; // Wise golden retriever
      utterance.rate = 0.92;
    } else {
      utterance.pitch = 1.0;
      utterance.rate = 1.0;
    }

    this.currentSpeaker = speaker;
    if (this.onSpeakingChange) this.onSpeakingChange(true, speaker);

    utterance.onend = () => {
      this.currentSpeaker = null;
      if (this.onSpeakingChange) this.onSpeakingChange(false, null);
    };

    utterance.onerror = () => {
      this.currentSpeaker = null;
      if (this.onSpeakingChange) this.onSpeakingChange(false, null);
    };

    try {
      this.synth.speak(utterance);
    } catch (e) {
      console.warn('SpeechSynthesis error', e);
    }
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.currentSpeaker = null;
      if (this.onSpeakingChange) this.onSpeakingChange(false, null);
    }
  }
}

export const speechEngine = new SpeechEngine();

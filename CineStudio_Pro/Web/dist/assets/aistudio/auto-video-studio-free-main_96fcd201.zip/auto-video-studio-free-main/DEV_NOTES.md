# Note di sviluppo e punti implementati/completabili

Ho implementato finora:
- scaffold completo con web UI (Flask) e frontend
- launcher START e script di setup per Windows e Linux
- orchestratore run.py che supporta esecuzione non interattiva via --project
- sistema di job async e logging nella web UI
- script per download modelli tramite HuggingFace (se token fornito)
- auto-update git pull all'avvio

Cosa è stato lasciato come "manuale" (non incluso automaticamente per ragioni pratiche e legali):
- download e installazione dei checkpoint proprietari (model.ckpt) che richiedono accettazione licenze: il processo è semi-automatico (download se token fornito)
- addestramento DreamBooth/LoRA (richiede dataset e tempo GPU)
- installazione di RIFE e altri repo di interpolazione (possibile ma può richiedere compilazione locale)

Miglioramenti che posso aggiungere se vuoi (li implemento direttamente nel repo su tua conferma):
- integrazione con Blender via script per creare parallax/camera 2.5D
- gestione asset (personaggi, voci, librerie SFX) con interfaccia drag&drop
- pipeline avanzata per ridurre numero di frame unici (render 3D/2D+parallax)
- supporto per multi-GPU e batching

Dimmi quali di questi vuoi che implementi subito e li aggiungo al repo.

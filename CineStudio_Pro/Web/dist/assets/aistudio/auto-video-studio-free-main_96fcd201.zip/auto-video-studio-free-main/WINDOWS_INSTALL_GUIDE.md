# Windows Installation & Usage Guide

Questo documento illustra i passaggi dettagliati per installare e avviare Auto Video Studio (completamente locale) su PC Windows. Ho automatizzato più operazioni possibili: creazione venv, installazione dipendenze Python, download di ffmpeg, clonazione opzionale di Automatic1111 (WebUI per Stable Diffusion), aggiornamento automatico del repository all'avvio, e strumenti per scaricare modelli (se fornisci token Hugging Face).

Prerequisiti hardware consigliati
- Windows 10/11 (64-bit)
- GPU NVIDIA con driver recenti (CUDA 11+ consigliata) per prestazioni. Funziona anche su CPU ma molto più lento.
- Python 3.10 o 3.11 installato e aggiunto al PATH
- Git installato e aggiunto al PATH
- Spazio su disco: minimo 50 GB libero; per modelli aggiuntivi potresti arrivare a 100+ GB

File importanti nel pacchetto
- START.bat -> launcher principale (effettua update e lancia la web UI)
- update_and_run.ps1 -> aggiorna il repo (git pull) e avvia il setup+UI
- setup_and_run.ps1 -> crea venv, installa requirements, scarica ffmpeg, clona Automatic1111 (opzionale) e avvia app
- app.py -> backend Flask (web UI)
- run.py -> orchestratore che esegue i project.json
- tools/ -> file scaricati (ffmpeg, automatic1111, ecc.)
- output/ -> progetti generati

Prima esecuzione (passi manuali minimi)
1. Scarica il repository ZIP o clonalo:
   git clone https://github.com/Bombolone92/auto-video-studio-free.git
2. Apri una PowerShell come amministratore nella cartella del progetto (consigliato)
3. Esegui:
   .\START.bat

Cosa succede all'avvio
- update_and_run.ps1 fa un git pull per aggiornare il repository locale (se hai una connessione Internet)
- setup_and_run.ps1 creerà venv nella stessa cartella (venv\) e installerà i pacchetti Python elencati in requirements.txt
- installer cerca e scarica automaticamente una build statica di ffmpeg e mette i binari in tools\ffmpeg
- l'installer clona Automatic1111 (opzionale): files in tools\automatic1111
- infine lancia la web UI locale (Flask) e apre il browser su http://127.0.0.1:5000

Note sui modelli (Stable Diffusion e altri)
- Alcuni modelli Stable Diffusion non sono liberamente scaricabili senza token HuggingFace (es. checkpoint ufficiali). Lo script download_models.py (opzionale) può scaricare modelli se fornisci HUGGINGFACE_TOKEN in .env.
- Non includiamo modelli proprietari direttamente nel repo.

Uso base della web UI
1. Crea un nuovo progetto con il pulsante "Nuovo Progetto"
2. Inserisci titolo, durata, prompt (o lascia che venga generato automaticamente)
3. Premi "Genera" per avviare la pipeline: l'orchestratore genererà keyframes, interpolerà (se RIFE installato), genererà TTS e assemblerà il video
4. Premi "Anteprima" per visualizzare il risultato nel player integrato
5. Premi "Esporta MP4" per scaricare il file finale

Se qualcosa va storto
- Controlla output/log nella cartella logs/ e nella UI (logOutput)
- Se l'installazione pip fallisce, assicurati che Python e pip siano aggiornati e che tu stia usando il venv creato
- Se non trovi modelli: fornisci HUGGINGFACE_TOKEN nella .env o scarica i file model.ckpt e mettili nella cartella tools\automatic1111\models

Prossimi passi (opzionali)
- Eseguire build EXE: esiste uno script build_exe.ps1 che utilizza PyInstaller per creare eseguibile. Richiede l'esecuzione sulla tua macchina.
- Installare RIFE per interpolazione frame avanzata: è opzionale ma consigliato.
- Addestrare LoRA/DreamBooth per coerenza personaggi: richiede dataset di immagini di riferimento e risorse GPU.

Supporto e debugging
Se vuoi, ti guiderò passo dopo passo via chat mentre esegui i comandi; controlla i log generati in logs/ e incolla qui gli errori che incontrerai.

# auto-video-studio-free

Progetto open-source per generare video animati (stile cinematografico per famiglie, originale, "inspirato a") interamente in locale. Lo script START avvia il setup automatico, scarica dipendenze essenziali (quando possibile), crea un ambiente virtuale isolato (venv), e avvia i componenti necessari.

ATTENZIONE e prerequisiti
- Non posso fornire modelli proprietari o credenziali. Alcuni checkpoint di Stable Diffusion richiedono un token Hugging Face: vedi sotto.
- Consigliato: Windows 10/11 con GPU NVIDIA e driver aggiornati. Funziona anche su Linux/macOS ma alcuni comandi nel launcher sono per Windows.
- Disco: decine di GB se scarichi modelli pesanti (Automatic1111, SD checkpoints, RIFE, ecc.).

Come usare (breve)
1. Scarica o clona questo repository sul tuo PC.
2. Metti il file START.bat nella cartella principale e fai doppio clic su START.bat (Windows) o usa start.sh su Linux.
3. Lo script creerà una cartella venv nella stessa directory e installerà dipendenze.
4. Se richiesto, fornisci il token HuggingFace (opzionale ma consigliato) e il sistema scaricherà automaticamente i modelli pubblici che non richiedono autenticazione.
5. Al termine del setup, il launcher avvierà i servizi (Automatic1111 WebUI se installato) e il programma principale che ti guiderà nella creazione dei video.

File principali
- START.bat / start.sh: launcher principale (Windows / Linux)
- setup_and_run.ps1 / setup_and_run.sh: script di setup che crea venv, installa dipendenze, scarica tool utili (ffmpeg), e lancia i servizi.
- run.py: orchestratore principale che guida la generazione (crea progetto, script, genera immagini tramite Automatic1111 API o diffusers fallback, usa RIFE per interpolazione, Coqui TTS per audio, monta con ffmpeg).
- requirements.txt: pacchetti Python per l'orchestratore (tentativo di installazione automatico).
- templates/sample_project.json: esempio di progetto (sinossi, durata, personaggi).

Disclaimer legale
- I video prodotti devono rispettare i ToS dei modelli e dei tool usati e le leggi sul copyright: il sistema non produce opere con marchi o stili protetti in modo identico; usa termini come "ispirato a" quando pubblichi.

Buon lavoro!

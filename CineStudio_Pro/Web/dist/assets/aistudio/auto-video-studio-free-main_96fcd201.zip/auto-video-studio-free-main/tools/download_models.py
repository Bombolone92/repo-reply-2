#!/usr/bin/env python3
"""
download_models.py
Script di supporto per scaricare modelli diffusers/ckpt da Hugging Face (se fornisci HUGGINGFACE_TOKEN in .env)
Non include modelli proprietari: devi avere i permessi per scaricare i modelli desiderati.
"""
import os
import requests
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).parent
load_dotenv(ROOT / '.env')
HF_TOKEN = os.getenv('HUGGINGFACE_TOKEN', '').strip()
MODELS_DIR = ROOT / 'tools' / 'models'
MODELS_DIR.mkdir(parents=True, exist_ok=True)

if not HF_TOKEN:
    print('HUGGINGFACE_TOKEN non trovato in .env. Apri .env e inserisci il token prima di usare questo script.')
    exit(1)

# esempio: scarica SD v1.5 (se disponibile e se hai accesso)
MODEL_ID = 'runwayml/stable-diffusion-v1-5'
print('Attempting to download model from', MODEL_ID)
from huggingface_hub import snapshot_download

try:
    path = snapshot_download(repo_id=MODEL_ID, cache_dir=str(MODELS_DIR), use_auth_token=HF_TOKEN)
    print('Modello scaricato in', path)
except Exception as e:
    print('Errore durante il download del modello:', e)

print('Fatto. Controlla la cartella', MODELS_DIR)

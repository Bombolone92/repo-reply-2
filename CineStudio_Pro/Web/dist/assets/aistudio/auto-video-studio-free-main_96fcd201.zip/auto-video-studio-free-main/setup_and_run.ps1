# setup_and_run.ps1 - Powershell setup/launcher (updated to start web UI)
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Auto Video Studio - setup in corso nella cartella: $root"
Set-Location $root
$venv_dir = Join-Path $root "venv"
if (-Not (Test-Path $venv_dir)) {
    Write-Host "Creazione ambiente virtuale..."
    python -m venv $venv_dir
} else { Write-Host "Ambiente virtuale già presente." }
$activate = Join-Path $venv_dir "Scripts\Activate.ps1"
if (Test-Path $activate) {
    Write-Host "Attivazione venv..."
    & $activate
} else { Write-Host "Attenzione: non ho trovato Activate.ps1. Assicurati di avere Python installato e nel PATH." }
Write-Host "Aggiorno pip e installo dipendenze minime..."
python -m pip install --upgrade pip
if (Test-Path "requirements.txt") {
    python -m pip install -r requirements.txt
}
# Scarica ffmpeg (static build) per Windows (64-bit)
$ffmpeg_dir = Join-Path $root "tools\ffmpeg"
if (-Not (Test-Path $ffmpeg_dir)) {
    New-Item -ItemType Directory -Path $ffmpeg_dir -Force | Out-Null
    Write-Host "Download ffmpeg static build..."
    $ffzip = Join-Path $ffmpeg_dir "ffmpeg.zip"
    $url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
    Invoke-WebRequest -Uri $url -OutFile $ffzip
    Write-Host "Estraggo ffmpeg..."
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($ffzip, $ffmpeg_dir)
    Remove-Item $ffzip
} else { Write-Host "ffmpeg già presente." }
# Clona Automatic1111 se l'utente vuole il backend potente
$auto_dir = Join-Path $root "tools\automatic1111"
if (-Not (Test-Path $auto_dir)) {
    Write-Host "Clonazione Automatic1111 WebUI (opzionale ma consigliata per qualità avanzata)."
    git clone https://github.com/AUTOMATIC1111/stable-diffusion-webui.git $auto_dir
    Write-Host "Clonato Automatic1111 in tools\automatic1111. Al primo avvio scaricherà modelli richiesti." 
} else { Write-Host "Automatic1111 già presente." }
Write-Host "Setup completato. Avvio web UI locale..."
# Avvia Flask app
Start-Process -FilePath "python" -ArgumentList "app.py" -WorkingDirectory $root

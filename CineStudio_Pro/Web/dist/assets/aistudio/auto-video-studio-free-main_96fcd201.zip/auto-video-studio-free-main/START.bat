@echo off
REM START.bat - Avvia il setup e l'orchestratore principale (Windows)
SETLOCAL ENABLEDELAYEDEXPANSION
REM Chiama lo script PowerShell che si occupa di creare venv e installare dipendenze
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0setup_and_run.ps1'"
pause

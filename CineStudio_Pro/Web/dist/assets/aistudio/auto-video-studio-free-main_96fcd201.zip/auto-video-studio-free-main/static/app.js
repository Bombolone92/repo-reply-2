const api = {
  list: '/api/projects',
  create: '/api/projects',
  generate: (p) => `/api/projects/${p}/generate`,
  status: (p) => `/api/projects/${p}/status`,
  preview: (p) => `/api/projects/${p}/preview`,
  download: (p) => `/api/projects/${p}/download`
}

async function $(sel){ return document.querySelector(sel) }

window.addEventListener('load', async ()=>{
  const projectsList = document.getElementById('projectsList')
  const newProjectBtn = document.getElementById('newProjectBtn')
  const genBtn = document.getElementById('genBtn')
  const previewBtn = document.getElementById('previewBtn')
  const exportBtn = document.getElementById('exportBtn')
  const projectTitle = document.getElementById('projectTitle')
  const duration = document.getElementById('duration')
  const promptBox = document.getElementById('promptBox')
  const previewVideo = document.getElementById('previewVideo')
  const logOutput = document.getElementById('logOutput')

  let selectedProject = null

  async function refreshList(){
    const res = await fetch(api.list)
    const data = await res.json()
    projectsList.innerHTML = ''
    data.forEach(p=>{
      const li = document.createElement('li')
      li.textContent = p.title
      li.onclick = ()=>{
        selectedProject = p.title
        projectTitle.value = p.title
        duration.value = p.meta.duration_min || 5
        promptBox.value = (p.meta.prompts || []).join('\n')
        highlightSelected()
      }
      projectsList.appendChild(li)
    })
  }

  function highlightSelected(){
    [...projectsList.children].forEach(li=>{
      li.style.background = (li.textContent===selectedProject)?'#ddd':'transparent'
    })
  }

  newProjectBtn.onclick = async ()=>{
    const title = prompt('Titolo progetto?','Episodio')
    if(!title) return
    const body = { title: title, duration_min: parseInt(duration.value||5), tone: 'Cinematografico, caldo', synopsis: promptBox.value || 'Una piccola avventura' }
    await fetch(api.create, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)})
    await refreshList()
  }

  genBtn.onclick = async ()=>{
    const title = projectTitle.value.trim().replace(/\s+/g,'_')
    if(!title){ alert('Inserisci un titolo progetto'); return }
    // save prompts to project
    const prompts = promptBox.value.split('\n').filter(s=>s.trim())
    await fetch(`/api/projects`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({title: title, duration_min: parseInt(duration.value||5), tone:'Cinematografico, caldo', synopsis: prompts[0]||'','prompts':prompts})})
    selectedProject = title
    await refreshList()
    const res = await fetch(api.generate(title), {method:'POST'})
    const json = await res.json()
    if(json.ok){
      logOutput.textContent = 'Generazione avviata... PID:' + json.pid
      pollStatus()
    } else { alert('Errore: ' + JSON.stringify(json)) }
  }

  previewBtn.onclick = async ()=>{
    if(!selectedProject){ alert('Seleziona o crea un progetto'); return }
    // try to load preview
    const url = api.preview(selectedProject)
    previewVideo.src = url
    previewVideo.load()
    previewVideo.play()
  }

  exportBtn.onclick = ()=>{
    if(!selectedProject){ alert('Seleziona o crea un progetto'); return }
    window.location = api.download(selectedProject)
  }

  async function pollStatus(){
    if(!selectedProject) return
    const res = await fetch(api.status(selectedProject))
    const json = await res.json()
    logOutput.textContent = json.log_tail || ''
    if(json.running){
      setTimeout(pollStatus, 2000)
    } else {
      logOutput.textContent += '\nGenerazione completata o terminata.'
    }
  }

  // input box behavior: Enter -> newline, Ctrl+Enter -> send (generate)
  promptBox.addEventListener('keydown', (e)=>{
    if(e.key==='Enter' && !e.ctrlKey){
      // insert newline (default) - do nothing special
      return
    }
    if(e.key==='Enter' && e.ctrlKey){
      e.preventDefault()
      genBtn.click()
    }
  })

  await refreshList()
})

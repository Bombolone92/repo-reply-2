#!/bin/bash
# setup_and_run.sh - setup per Linux/macOS (aggiornato per lanciare web UI)
set -e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Auto Video Studio - setup in $ROOT_DIR"
cd "$ROOT_DIR"
if [ ! -d "venv" ]; then
  echo "Creazione virtualenv..."
  python3 -m venv venv
fi
. venv/bin/activate
pip install --upgrade pip
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
fi
# ffmpeg
TOOLS_DIR="$ROOT_DIR/tools"
mkdir -p "$TOOLS_DIR"
if [ ! -d "$TOOLS_DIR/ffmpeg" ]; then
  echo "Scarico ffmpeg..."
  if [ "$(uname)" = "Linux" ]; then
    wget -O /tmp/ffmpeg.tar.xz https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz
    tar -xJf /tmp/ffmpeg.tar.xz -C "$TOOLS_DIR"
  else
    echo "Per macOS o altri sistemi, installa ffmpeg tramite homebrew o pacman."
  fi
fi
# Automatic1111
if [ ! -d "tools/automatic1111" ]; then
  echo "Clonazione Automatic1111 WebUI (opzionale)..."
  git clone https://github.com/AUTOMATIC1111/stable-diffusion-webui.git tools/automatic1111
fi
# Avvia web UI
python3 app.py

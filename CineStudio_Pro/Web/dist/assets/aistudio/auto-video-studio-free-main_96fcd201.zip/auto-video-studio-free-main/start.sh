#!/bin/bash
# start.sh - launcher per Linux/macOS
DIR="$(cd "$(dirname "$0")" && pwd)"
bash "$DIR/setup_and_run.sh"

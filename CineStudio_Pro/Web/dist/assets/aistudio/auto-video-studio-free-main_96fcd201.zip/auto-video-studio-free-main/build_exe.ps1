# build_exe.ps1
# Script opzionale per creare un eseguibile Windows con PyInstaller.
# Nota: devi eseguirlo sulla tua macchina Windows e avere PyInstaller installato nel venv.
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $root
if (-Not (Test-Path "venv")) { Write-Host "Crea prima il venv eseguendo START.bat"; exit }
& .\venv\Scripts\Activate.ps1
pip install pyinstaller
pyinstaller --onefile --add-data "templates;templates" --add-data "static;static" app.py
Write-Host "Eseguibile creato nella cartella dist\"

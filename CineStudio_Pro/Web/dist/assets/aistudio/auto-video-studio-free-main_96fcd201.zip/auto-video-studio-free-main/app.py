from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_cors import CORS
import os, subprocess, threading, time, json, sys, webbrowser
from pathlib import Path

ROOT = Path(__file__).parent
OUTPUT = ROOT / "output"
PROJECTS = OUTPUT
RUN_SCRIPT = ROOT / 'run.py'
LOGS = ROOT / 'logs'

os.makedirs(OUTPUT, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

jobs = {}  # title -> subprocess info

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/projects', methods=['GET'])
def list_projects():
    res = []
    for d in PROJECTS.iterdir():
        if d.is_dir():
            proj_file = d / 'project.json'
            if proj_file.exists():
                with open(proj_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                res.append({'title': d.name, 'meta': data})
    return jsonify(res)

@app.route('/api/projects', methods=['POST'])
def create_project():
    body = request.json
    title = body.get('title', 'Progetto').strip().replace(' ', '_')
    duration_min = int(body.get('duration_min', 5))
    tone = body.get('tone', '')
    synopsis = body.get('synopsis', '')
    prompts = body.get('prompts')
    if not prompts:
        # simple auto prompt generation
        total_seconds = duration_min * 60
        shot_length = 5
        nshots = max(1, total_seconds // shot_length)
        prompts = [f"{tone}, scena {i+1}, {synopsis}, carattere espressivo, illuminazione cinematografica" for i in range(int(nshots))]
    projdir = PROJECTS / title
    projdir.mkdir(parents=True, exist_ok=True)
    project = {
        'title': title,
        'duration_min': duration_min,
        'tone': tone,
        'synopsis': synopsis,
        'prompts': prompts
    }
    with open(projdir / 'project.json', 'w', encoding='utf-8') as f:
        json.dump(project, f, ensure_ascii=False, indent=2)
    return jsonify({'ok': True, 'path': str(projdir)})

@app.route('/api/projects/<project>/generate', methods=['POST'])
def generate_project(project):
    projdir = PROJECTS / project
    pj = projdir / 'project.json'
    if not pj.exists():
        return jsonify({'error': 'project not found'}), 404
    if project in jobs and jobs[project].get('running'):
        return jsonify({'error': 'already running'}), 400
    log_path = LOGS / f"{project}.log"
    # launch run.py --project <path>
    cmd = [sys.executable, str(RUN_SCRIPT), '--project', str(pj)]
    f = open(log_path, 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT)
    jobs[project] = {'proc': proc, 'log': str(log_path), 'started_at': time.time(), 'running': True}

    def monitor(pname):
        proc.wait()
        jobs[pname]['running'] = False
        f.close()
    t = threading.Thread(target=monitor, args=(project,), daemon=True)
    t.start()
    return jsonify({'ok': True, 'pid': proc.pid})

@app.route('/api/projects/<project>/status', methods=['GET'])
def project_status(project):
    if project not in jobs:
        return jsonify({'running': False, 'log': None})
    info = jobs[project]
    running = info['running']
    logpath = info['log']
    tail = ''
    try:
        with open(logpath, 'r', encoding='utf-8') as f:
            tail = f.read()[-2000:]
    except Exception:
        tail = ''
    return jsonify({'running': running, 'log_tail': tail})

@app.route('/api/projects/<project>/preview', methods=['GET'])
def project_preview(project):
    projdir = PROJECTS / project
    final = projdir / 'final_video.mp4'
    if final.exists():
        return send_from_directory(str(projdir), 'final_video.mp4')
    # maybe named final_video.mp4 or final_video
    for f in projdir.glob('*.mp4'):
        return send_from_directory(str(projdir), f.name)
    return jsonify({'error': 'no video yet'}), 404

@app.route('/api/projects/<project>/download', methods=['GET'])
def project_download(project):
    projdir = PROJECTS / project
    final = projdir / 'final_video.mp4'
    if final.exists():
        return send_from_directory(str(projdir), 'final_video.mp4', as_attachment=True)
    return jsonify({'error': 'no video yet'}), 404

if __name__ == '__main__':
    port = int(os.environ.get('AVS_PORT', 5000))
    url = f'http://127.0.0.1:{port}'
    print('Starting web UI at', url)
    webbrowser.open(url)
    app.run(host='127.0.0.1', port=port)

# update_and_run.ps1
# Script di update + avvio principale per Windows
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Auto Video Studio - checking updates in: $root"
Set-Location $root
# Se siamo dentro una cartella git, esegui git pull
if (Test-Path (Join-Path $root '.git')) {
    Write-Host "Repository git trovato. Effettuo git pull..."
    try{
        git -C $root pull
    } catch {
        Write-Host "git pull fallito: $_"
    }
} else { Write-Host "Cartella non è un repo git. Salta aggiornamento automatico." }
# Dopo aggiornamento, esegui lo script di setup e run
$setup = Join-Path $root 'setup_and_run.ps1'
if (Test-Path $setup) {
    Write-Host "Avvio setup_and_run.ps1..."
    powershell -NoProfile -ExecutionPolicy Bypass -File $setup
} else {
    Write-Host "setup_and_run.ps1 non trovato. Eseguo run.py direttamente..."
    python run.py
}

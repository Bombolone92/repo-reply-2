# Note di rilascio

Questo commit iniziale crea lo scheletro del progetto "auto-video-studio-free" con i seguenti contenuti:
- Launcher (START.bat, start.sh)
- Setup script (PowerShell / bash)
- Orchestratore Python (run.py)
- Requirements file
- README e licenza

Prossimi passi raccomandati:
- Eseguire START.bat su Windows (come amministratore se necessario) e lasciare che lo script configuri l'ambiente.
- Fornire un token HuggingFace nel file .env se vuoi che il sistema scarichi automaticamente i modelli diffusers non pubblici.


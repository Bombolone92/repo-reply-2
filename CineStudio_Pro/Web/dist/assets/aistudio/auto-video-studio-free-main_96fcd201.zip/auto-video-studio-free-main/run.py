#!/usr/bin/env python3
"""
run.py - Orchestratore principale modificato per supportare --project <path>
Se chiamato con --project, esegue la generazione non interattiva.
"""
import os
import sys
import time
import json
import requests
import subprocess
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).parent
TOOLS = ROOT / "tools"
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)

load_dotenv(dotenv_path=ROOT / '.env')
HUGGINGFACE_TOKEN = os.getenv('HUGGINGFACE_TOKEN', '').strip()
WEBUI_URL = "http://127.0.0.1:7860"


def find_ffmpeg():
    ff = TOOLS / 'ffmpeg'
    if ff.exists():
        for p in ff.rglob('ffmpeg.exe'):
            return str(p)
        for p in ff.rglob('ffmpeg'):
            return str(p)
    return 'ffmpeg'


def generate_images_with_automatic(prompts, outdir):
    print("Generazione immagini tramite Automatic1111 API...")
    os.makedirs(outdir, exist_ok=True)
    for i,p in enumerate(prompts):
        payload = {
            "prompt": p,
            "steps": 30,
            "width": 1024,
            "height": 576,
            "sampler_index": "Euler",
            "cfg_scale": 7.0
        }
        try:
            r = requests.post(WEBUI_URL + "/sdapi/v1/txt2img", json=payload, timeout=120)
            r.raise_for_status()
            j = r.json()
            img_b64 = j['images'][0]
            import base64
            outpath = os.path.join(outdir, f"frame_{i:04d}.png")
            with open(outpath, 'wb') as f:
                f.write(base64.b64decode(img_b64))
            print("Creato", outpath)
        except Exception as e:
            print('Errore durante chiamata Automatic1111:', e)
            break
    return sorted([str(p) for p in Path(outdir).glob('*.png')])


def generate_images_with_diffusers(prompts, outdir):
    print("Fallback: generazione immagini con diffusers (se disponibile)")
    try:
        from diffusers import StableDiffusionPipeline
        import torch
        model_id = "runwayml/stable-diffusion-v1-5"
        if not HUGGINGFACE_TOKEN:
            print("ATTENZIONE: per scaricare modelli da HuggingFace potrebbe esserci bisogno di un token. Aggiungi HUGGINGFACE_TOKEN nella .env")
        pipe = StableDiffusionPipeline.from_pretrained(model_id, use_auth_token=HUGGINGFACE_TOKEN)
        pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
        os.makedirs(outdir, exist_ok=True)
        for i,p in enumerate(prompts):
            img = pipe(p, guidance_scale=7.5, num_inference_steps=30).images[0]
            outpath = os.path.join(outdir, f"frame_{i:04d}.png")
            img.save(outpath)
            print("Creato", outpath)
        return sorted([str(p) for p in Path(outdir).glob('*.png')])
    except Exception as e:
        print("Errore nel fallback diffusers:", e)
        return []


def interpolate_with_rife(frames_dir, out_video):
    print("Tentativo di interpolazione con RIFE (se installato)...")
    rife_script = TOOLS / 'rife' / 'inference_video.py'
    if rife_script.exists():
        cmd = [sys.executable, str(rife_script), '--input', str(frames_dir), '--output', str(out_video), '--fps', '30']
        subprocess.run(cmd, check=True)
        return out_video
    else:
        print("RIFE non trovato: creo video con ffmpeg senza interpolazione.")
        ffmpeg_bin = find_ffmpeg()
        cmd = [ffmpeg_bin, '-y', '-framerate', '1', '-i', f"{frames_dir}/frame_%04d.png", '-c:v', 'libx264', '-pix_fmt', 'yuv420p', str(out_video)]
        subprocess.run(cmd, check=True)
        return out_video


def synthesize_voice(text, outwav):
    print("Generazione TTS con Coqui TTS (se disponibile)...")
    try:
        cmd = ['tts', '--text', text, '--out_path', outwav]
        subprocess.run(cmd, check=True)
        return outwav
    except Exception as e:
        print('Errore generazione TTS:', e)
        return None


def assemble_video_with_audio(video_mp4, audio_wav, final_out):
    ffmpeg = find_ffmpeg()
    cmd = [ffmpeg, '-y', '-i', video_mp4, '-i', audio_wav, '-c:v', 'copy', '-c:a', 'aac', final_out]
    subprocess.run(cmd, check=True)
    return final_out


def generate_from_project(projpath):
    projpath = Path(projpath)
    if not projpath.exists():
        print('Project file not found:', projpath)
        return
    with open(projpath, 'r', encoding='utf-8') as f:
        project = json.load(f)
    title = project.get('title', projpath.parent.name)
    print('Generazione del progetto:', title)
    frames_dir = projpath.parent / 'frames'
    frames_dir.mkdir(parents=True, exist_ok=True)
    prompts = project.get('prompts', [])
    # try automatic1111 first
    try:
        r = requests.get(WEBUI_URL + '/sdapi/v1/sd-models', timeout=2)
        has_auto = (r.status_code == 200)
    except Exception:
        has_auto = False
    if has_auto:
        frames = generate_images_with_automatic(prompts, str(frames_dir))
    else:
        frames = generate_images_with_diffusers(prompts, str(frames_dir))
    if not frames:
        print('Nessuna immagine generata, esco.')
        return
    video_tmp = projpath.parent / 'video_tmp.mp4'
    interpolate_with_rife(str(frames_dir), str(video_tmp))
    audio = projpath.parent / 'voice.wav'
    synthesize_voice(project.get('synopsis',''), str(audio))
    final = projpath.parent / 'final_video.mp4'
    assemble_video_with_audio(str(video_tmp), str(audio), str(final))
    print('Generazione completata. File finale:', final)


def create_project_interactive():
    # keep existing interactive behavior for backward compatibility
    print('Modalità interattiva non implementata in questa build.')

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', help='Percorso al file project.json da eseguire', default=None)
    args = parser.parse_args()
    if args.project:
        generate_from_project(args.project)
    else:
        create_project_interactive()
